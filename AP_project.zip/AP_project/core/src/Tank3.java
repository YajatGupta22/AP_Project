import com.mygdx.game.Tank;

public class Tank3 extends Tank {
}
