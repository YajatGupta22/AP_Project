package com.mygdx.game;

public class Tank2 extends Tank{
}
