package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

import java.io.Serializable;

public class SavedGames implements Screen, Serializable {
    private SpriteBatch batch;
    private Texture img;
    private Stage stage;
    private Game game;
    private Label outputLabel;

    public SavedGames(Game aGame) {
        game = aGame;
        stage = new Stage(new ScreenViewport());
        Skin mySkin=new Skin(Gdx.files.internal("skin/star-soldier-ui.json"));

        TextButton tank2 = new TextButton("Select",mySkin);
        tank2.setSize(Gdx.graphics.getWidth()/4+10,Gdx.graphics.getHeight()/6-10);
        tank2.setPosition(Gdx.graphics.getWidth()/2-tank2.getWidth()/2+4,Gdx.graphics.getHeight()/2-tank2.getHeight()/2-149);
        tank2.addListener(new InputListener(){
            @Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
                game.setScreen(new GameScreen(game));
            }
            @Override
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
                return true;
            }
        });

        TextButton tank1 = new TextButton("Select",mySkin);
        tank1.setSize(Gdx.graphics.getWidth()/4+10,Gdx.graphics.getHeight()/6-10);
        tank1.setPosition(tank2.getX()-205, tank2.getY());
        tank1.addListener(new InputListener(){
            @Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
                game.setScreen(new GameScreen(game));
            }
            @Override
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
                return true;
            }
        });



        TextButton tank3 = new TextButton("Select",mySkin);
        tank3.setSize(Gdx.graphics.getWidth()/4+10,Gdx.graphics.getHeight()/6-10);
        tank3.setPosition(tank2.getX()+205, tank2.getY());
        tank3.addListener(new InputListener(){
            @Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
                game.setScreen(new GameScreen(game));
            }
            @Override
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
                return true;
            }
        });


        batch = new SpriteBatch();
        img = new Texture("Saved Games.png");
        stage.addActor(tank1);
        stage.addActor(tank2);
        stage.addActor(tank3);

    }

    public void create () {

    }


    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        batch.begin();
        batch.draw(img, 0, 20,638,440);
        batch.end();
        stage.act();
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose () {
        batch.dispose();
        img.dispose();
        stage.dispose();
    }
}

