package com.mygdx.game;

public class Tank1 extends Tank{
}
