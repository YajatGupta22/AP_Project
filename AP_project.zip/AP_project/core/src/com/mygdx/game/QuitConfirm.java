package com.mygdx.game;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

import java.io.Serializable;

public class QuitConfirm implements Screen, Serializable {
    private SpriteBatch batch;
    private Texture img;
    private Stage stage;
    private Game game;

    public QuitConfirm(Game aGame){
        game = aGame;
        stage = new Stage(new ScreenViewport());
        Skin mySkin=new Skin(Gdx.files.internal("skin/star-soldier-ui.json"));

        final TextButton Yes = new TextButton("Yes",TankStars.myskin);
        Yes.setWidth(Gdx.graphics.getWidth()/5);
        Yes.setHeight(Gdx.graphics.getHeight()/4-40);
        Yes.setPosition(Gdx.graphics.getWidth()/2-Yes.getWidth()/2-40,Gdx.graphics.getHeight()/2-Yes.getHeight()/2-50);
        Yes.addListener(new InputListener(){
            @Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
                game.setScreen(new MainMenu(game));
            }
            @Override
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
                return true;
            }
        });
        final TextButton NO = new TextButton("No",TankStars.myskin);
        NO.setWidth(Gdx.graphics.getWidth()/5);
        NO.setHeight(Gdx.graphics.getHeight()/4-40);
        NO.setPosition(Yes.getX()+Yes.getWidth()-30, Yes.getY());
        NO.addListener(new InputListener(){
            @Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
                game.setScreen(new GameScreen(game));
            }
            @Override
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
                return true;
            }
        });
        batch = new SpriteBatch();
        img = new Texture("3.jpg");
        stage.addActor(Yes);
        stage.addActor(NO);

    }

    public void create () {

    }


    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        batch.begin();
        batch.draw(img, 0, 20,638,440);
//        tank.font.draw(batch,"Are you sure you want to Quit?",290,180);
        batch.end();
        stage.act();
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose () {
        batch.dispose();
        img.dispose();
        stage.dispose();
    }
    }

