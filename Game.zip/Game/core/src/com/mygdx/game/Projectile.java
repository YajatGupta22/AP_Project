package com.mygdx.game;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;

public class Projectile extends Template {
    //final Tank game;

    private static float a = 5;
    private static float b = 5;

    public static float getA() {
        return a;
    }

    public static float getB() {
        return b;
    }

    private Texture OrangeRectangle;
    private Rectangle rectangle;



    public Vector2 startVelocity = new Vector2(a,b);
    public Vector2 startPoint = new Vector2(0,0);
    public Projectile(float x, float y){
        //this.game = game;
        try{
        bomb = new Texture("bomb.png");
        }
        catch (Exception e){

        }
        this.x = x;
        this.y = y;
    }
    public static void ReduceAngle(float t){
        if(b>0) {
            Projectile.b -= t * b;
            Projectile.a = (float) Math.pow(50 - (b * b), 0.5);
        }
    }
    public static void IncreaseAngle(float t){
        if(a>0){
            Projectile.b += t * b;
            Projectile.a = (float) Math.pow(50 - (b*b),0.5);
        }

    }

    public void setRectangleDimensions() {
        rectangle.x = 10;
        rectangle.y = 20;
        rectangle.width = 1;
        rectangle.height = 10;
    }

    @Override
    public void Update(float t){
        x = a * t + x;
        y = 0.5f * gravity * t * t + b * t + y;
        if(this.y<60){
            remove = true;
        }
    }


}
