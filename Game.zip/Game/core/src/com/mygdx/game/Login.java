package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

import java.io.Serializable;

public class Login implements Screen, Serializable {
    private SpriteBatch batch;
    private Texture img;
    private Stage stage;
    private TankStars game;
    private Label outputLabel;

    public Login(TankStars aGame) {
        game = aGame;
        stage = new Stage(new ScreenViewport());
        Skin mySkin=new Skin(Gdx.files.internal("skin/star-soldier-ui.json"));

        final TextButton resume = new TextButton("Login",TankStars.myskin);
        resume.setWidth(Gdx.graphics.getWidth()/3);
        resume.setHeight(Gdx.graphics.getHeight()/4-25);
        resume.setPosition(Gdx.graphics.getWidth()/2-resume.getWidth()/2,Gdx.graphics.getHeight()/2-resume.getHeight()/2 - 137);
        resume.addListener(new InputListener(){
            @Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
                game.setScreen(new GameScreen(game,new TankMovement()));
            }
            @Override
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
                return true;
            }
        });


        batch = new SpriteBatch();
        img = new Texture("Login.jpeg");
        stage.addActor(resume);


    }

    public void create () {

    }


    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        batch.begin();
        batch.draw(img, 0, 20,638,440);
        batch.end();
        stage.act();
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose () {
        batch.dispose();
        img.dispose();
        stage.dispose();
    }
}
