package com.mygdx.game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;

import java.io.Serializable;

import com.badlogic.gdx.scenes.scene2d.ui.Image;



public class TankMovement extends Image implements Serializable {
    Rectangle Tank1;
    Rectangle Tank2;
    Rectangle Health1;
    Rectangle Health2;
    Texture Tank1Image;
    Texture Tank2Image;
    Texture Health1Img;
    Texture Health2Img;

    private Vector2 velocity1;
    private float SPEED;

    public TankMovement(){
        Tank1Image = new Texture(Gdx.files.internal("Abrams.png"));
        Tank2Image = new Texture(Gdx.files.internal("FrostReversed.png"));
        Health1Img = new Texture(Gdx.files.internal("OrangeRectangle.png"));
        Health2Img = new Texture(Gdx.files.internal("OrangeRectangle.png"));
        velocity1 = new Vector2();
        SPEED = 50;
        Tank1 = new Rectangle();
        Tank2 = new Rectangle();
        Health1 = new Rectangle();
        Health2 = new Rectangle();

        Tank1.x = 0;
        Tank1.y = 120;
        Tank1.width = 94;
        Tank1.height = 94;

        Tank2.x = 530;
        Tank2.y = 120;
        Tank2.width =94;
        Tank2.height =94;

        Health1.x = 100;
        Health1.y = 420;
        Health1.width = 100;
        Health1.height = 16;

        Health2.x = 420;
        Health2.y = 420;
        Health2.width = 100;
        Health2.height = 16;

    }

    public void act(float delta) {
        super.act(delta);
//        this.setRotation(body.getAngle() * MathUtils.radiansToDegrees);
        this.setPosition(Tank1.x-this.getWidth()/2 , Tank1.y -this.getHeight()/2);
        this.setPosition(Tank2.x-this.getWidth()/2 , Tank2.y -this.getHeight()/2);

    }

}
