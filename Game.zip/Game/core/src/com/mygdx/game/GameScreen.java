package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;


public class GameScreen implements Screen, Serializable {
    private SpriteBatch batch;
    private Texture img;
    private Stage stage;
    private TankStars game;
    final TankMovement Tanks;
    private Texture img2;
    private OrthographicCamera camera;
    private FitViewport viewport;
    //private Rectangle dot;
    //private Texture whitedot;
    static TankMovement Tank1;
    static TankMovement tank1;
    static TankMovement tank2;
    static TankMovement tank3;
    private Rectangle rectangle1;
    private Rectangle rectangle2;
    private Rectangle rectangle3;
    private Rectangle rectangle4;
    private Texture angle1;
    private Texture angle2;
    private ArrayList<Projectile> projectiles;
    private ArrayList<ReverseProjectile> reverseProjectiles;
    static int flag=0;

    public GameScreen(TankStars aGame, TankMovement tanks){

//        Gdx.app.setLogLevel(Application.LOG_DEBUG);
        game = aGame;
        this.Tanks=tanks;
        GameScreen.Tank1 = this.Tanks;
        stage = new Stage(new ScreenViewport());

        Skin mySkin=new Skin(Gdx.files.internal("skin/star-soldier-ui.json"));




        batch = new SpriteBatch();
        img = new Texture("2.jpg");

        rectangle3 = new Rectangle();
        rectangle4 = new Rectangle();
        angle1 = new Texture("BlueRectangle.png");
        angle2 = new Texture("BlueRectangle.png");
//        health1 = new Texture("OrangeRectangle.png");
//        health2 = new Texture("OrangeRectangle.png");
        img2 = new Texture("Ground2.jpg");
        camera = new OrthographicCamera();
        camera.setToOrtho(false, 800, 480);
        this.viewport = new FitViewport(0, 0, camera);
        Gdx.input.setInputProcessor(stage);

        projectiles = new ArrayList<Projectile>();
        reverseProjectiles = new ArrayList<ReverseProjectile>();


        rectangle3.x = 40;
        rectangle3.y = 20;
        rectangle3.width = 10;
        rectangle3.height = 1;
        rectangle4.x = 540;
        rectangle4.y = 20;
        rectangle4.width = 10;

        final TextButton resume = new TextButton("Resume",TankStars.myskin);
        resume.setWidth(Gdx.graphics.getWidth()/3);
        resume.setHeight(Gdx.graphics.getHeight()/4-25);
        resume.setPosition(Gdx.graphics.getWidth()/2-resume.getWidth()/2,Gdx.graphics.getHeight()/2-resume.getHeight()/2+150);
        resume.addListener(new InputListener(){
            @Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
                game.setScreen(new GameScreen(game, Tank1));
            }
            @Override
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
                return true;
            }
        });
        final TextButton Save = new TextButton("Save Game",TankStars.myskin);
        Save.setWidth(Gdx.graphics.getWidth()/3);
        Save.setHeight(Gdx.graphics.getHeight()/4-25);
        Save.setPosition(resume.getX(), resume.getY()- Save.getHeight());
        Save.addListener(new InputListener(){
            @Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
                try{
                    flag++;

                    if(flag==1){
                        tank1=Tank1;
                    }
                    else if(flag==2){
                        tank2=Tank1;
                    }
                    else if(flag==3){
                        tank3=Tank1;
                    }
                    else if(flag==4){
                        System.out.println("No more space");
                    }
                    File f = new File("save.txt");
                    FileOutputStream fos = new FileOutputStream(f);
                    ObjectOutputStream oos = new ObjectOutputStream(fos);
                    oos.writeObject(Tank1);

                    FileInputStream fis = new FileInputStream(f);
                    ObjectInputStream ois = new ObjectInputStream(fis);
                    TankMovement Tanks1 = (TankMovement) ois.readObject();
                    game.setScreen(new GameScreen(game , Tanks1));


                }
                catch (Exception e){
                    System.out.println("Job Done");
                }
            }
            @Override
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
                return true;
            }
        });

        final TextButton Menu = new TextButton("Main Menu",TankStars.myskin);
        Menu.setWidth(Gdx.graphics.getWidth()/3);
        Menu.setHeight(Gdx.graphics.getHeight()/4-25);
        Menu.setPosition(resume.getX(), Save.getY()- Menu.getHeight());
        Menu.addListener(new InputListener(){
            @Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
                game.setScreen(new MainMenu(game));
            }
            @Override
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
                return true;
            }
        });

        final TextButton Quit = new TextButton("Quit",TankStars.myskin);
        Quit.setWidth(Gdx.graphics.getWidth()/3);
        Quit.setHeight(Gdx.graphics.getHeight()/4-25);
        Quit.setPosition(resume.getX(), Menu.getY()- Quit.getHeight());
        Quit.addListener(new InputListener(){
            @Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
                game.setScreen(new QuitConfirm(game));
            }
            @Override
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
                return true;
            }
        });

        ImageButton pause = new ImageButton(mySkin);
        pause.setSize(Gdx.graphics.getWidth()/5-22,Gdx.graphics.getHeight()/5-20);
        pause.getStyle().imageUp = new TextureRegionDrawable(new TextureRegion(new Texture(Gdx.files.internal("pause.png"))));
        pause.getStyle().imageDown = new TextureRegionDrawable(new TextureRegion(new Texture(Gdx.files.internal("pause.png"))));
        pause.setPosition(Gdx.graphics.getWidth()-110,Gdx.graphics.getHeight()-100);
        pause.addListener(new InputListener(){
            @Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
                stage.addActor(resume);
                stage.addActor(Save);
                stage.addActor(Menu);
                stage.addActor(Quit);
            }
            @Override
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
                return true;
            }
        });

        stage.addActor(pause);

    }
    @Override
    public void show() {

    }
    float t = 0f;
    float t2 = 0f;
    int count = 0;

    @Override
    public void render(float delta) {


        if(Gdx.input.isKeyPressed(Input.Keys.SPACE)){
            if (count % 2 == 0) {
                projectiles.add(new Projectile(Tanks.Tank1.getX() + 55, Tanks.Tank1.getY() + 32));

                count++;
            }
        }


        if(Gdx.input.isKeyPressed(Input.Keys.L)){
            if (count % 2 != 0) {
                reverseProjectiles.add(new ReverseProjectile(Tanks.Tank2.getX() , Tanks.Tank2.getY() + 32));
                count++;
            }
        }

        if(Gdx.input.isKeyPressed(Input.Keys.S)){
            Projectile.ReduceAngle(Gdx.graphics.getDeltaTime());
            if(Projectile.getB() > 0 && rectangle3.height>1){
                rectangle3.height -= 100*Gdx.graphics.getDeltaTime();
            }
        }
        if(Gdx.input.isKeyPressed(Input.Keys.W)){
            Projectile.IncreaseAngle(Gdx.graphics.getDeltaTime());
            if(Projectile.getA() > 0 && rectangle3.height<50){
                rectangle3.height += 100*Gdx.graphics.getDeltaTime();
            }
        }

        if(Gdx.input.isKeyPressed(Input.Keys.DOWN)){
            ReverseProjectile.ReduceAngle(Gdx.graphics.getDeltaTime());
            if(ReverseProjectile.getB() > 0 && rectangle4.height>1){
                rectangle4.height -= 100*Gdx.graphics.getDeltaTime();
            }
        }
        if(Gdx.input.isKeyPressed(Input.Keys.UP)){
            ReverseProjectile.IncreaseAngle(Gdx.graphics.getDeltaTime());
            if(ReverseProjectile.getA() > 0 && rectangle4.height<50){
                rectangle4.height += 100*Gdx.graphics.getDeltaTime();
            }
        }

        //health

        if(!projectiles.isEmpty() && projectiles.get(0).getX() < (Tanks.Tank2.getX()+Tanks.Tank2.width) && projectiles.get(0).getY() < (Tanks.Tank2.getY()+Tanks.Tank2.height)){
            if(Tanks.Tank2.getX() < projectiles.get(0).getX() && Tanks.Tank2.getY() < projectiles.get(0).getY() && Tanks.Health2.width >=0){
                Tanks.Health2.width -= 2;
            }
        }

        if(!reverseProjectiles.isEmpty() && reverseProjectiles.get(0).getX() < (Tanks.Tank1.getX()+Tanks.Tank1.width) && reverseProjectiles.get(0).getY() < (Tanks.Tank1.getY()+Tanks.Tank1.height)){
            if(Tanks.Tank1.getX() < reverseProjectiles.get(0).getX() && Tanks.Tank1.getY() < reverseProjectiles.get(0).getY() && Tanks.Health1.width >=0){
                Tanks.Health1.width -= 2;
            }
        }
        if(Tanks.Health2.width <0){
            System.out.println("Player 1 wins");
            game.setScreen(new GameOver(game));
        }
        if(Tanks.Health1.width <0){
            System.out.println("Player 2 wins");
            game.setScreen(new GameOver(game));
        }

        ArrayList<Projectile> projectilesToRemove = new ArrayList<Projectile>();
        ArrayList<ReverseProjectile> reverseProjectilesToRemove = new ArrayList<ReverseProjectile>();



        for(Projectile projectile : projectiles){
            t+=(Gdx.graphics.getDeltaTime());
            projectile.Update(t);
            if(projectile.remove){
                projectilesToRemove.add(projectile);
                t=0f;
            }
        }
        projectiles.removeAll(projectilesToRemove);


        for(ReverseProjectile reverseProjectile : reverseProjectiles){
            t2+=(Gdx.graphics.getDeltaTime());
            reverseProjectile.Update(t2);
            if(reverseProjectile.remove){
                reverseProjectilesToRemove.add(reverseProjectile);
                t2=0f;
            }
        }
        reverseProjectiles.removeAll(reverseProjectilesToRemove);



        if (Gdx.input.isKeyPressed(Input.Keys.A)) {
                Tanks.Tank1.x -= 100 * Gdx.graphics.getDeltaTime();

        }
        if (Gdx.input.isKeyPressed(Input.Keys.D)) {
                Tanks.Tank1.x += 100 * Gdx.graphics.getDeltaTime();

        }
        if (Tanks.Tank1.x < 0)
            Tanks.Tank1.x = 0;
        if (Tanks.Tank1.y < 0)
            Tanks.Tank1.y = 0;
        if (Tanks.Tank1.x > 580)
            Tanks.Tank1.x = 580;

        if (Gdx.input.isKeyPressed(Input.Keys.LEFT))
            Tanks.Tank2.x -= 100 * Gdx.graphics.getDeltaTime();
        if (Gdx.input.isKeyPressed(Input .Keys.RIGHT))
            Tanks.Tank2.x += 100 * Gdx.graphics.getDeltaTime();

        if (Tanks.Tank2.x < 0)
            Tanks.Tank2.x = 0;
        if (Tanks.Tank2.x > 530)
            Tanks.Tank2.x = 530;
        ScreenUtils.clear(0, 0, 0, 0);
        camera.update();
        game.batch.setProjectionMatrix(camera.combined);
        game.batch.begin();
        game.batch.draw(img2, 0, 0,660,480);
        game.batch.draw(Tanks.Tank1Image, Tanks.Tank1.x, Tanks.Tank1.y, Tanks.Tank1.width, Tanks.Tank1.height);
        game.batch.draw(Tanks.Tank2Image, Tanks.Tank2.x, Tanks.Tank2.y, Tanks.Tank2.width, Tanks.Tank2.height);
        game.batch.draw(Tanks.Health1Img, Tanks.Health1.x, Tanks.Health1.y, Tanks.Health1.width, Tanks.Health1.height);
        game.batch.draw(Tanks.Health2Img, Tanks.Health2.x, Tanks.Health2.y, Tanks.Health2.width, Tanks.Health2.height);
        game.batch.draw(angle1, rectangle3.x, rectangle3.y, rectangle3.width, rectangle3.height);
        game.batch.draw(angle2, rectangle4.x, rectangle4.y, rectangle4.width, rectangle4.height);
        //game.getBatch().draw(whitedot, dot.x, dot.y, dot.width, dot.height);
        for(Projectile projectile : projectiles){
            projectile.render(game.batch);
        }
        for(ReverseProjectile reverseProjectile : reverseProjectiles){
            reverseProjectile.render(game.batch);
        }
        game.batch.end();

        stage.act();
        stage.draw();


    }

    @Override
    public void resize(int width, int height) {
        camera.setToOrtho(false, width, height);
        viewport.setWorldSize(width, height);
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        img2.dispose();
    }




    }





