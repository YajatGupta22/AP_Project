package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

import java.io.Serializable;

public class SavedGames implements Screen, Serializable {
    private SpriteBatch batch;
    private Texture img;
    private Stage stage;
    private TankStars game;
    private Label outputLabel;

    public SavedGames(TankStars aGame) {
        game = aGame;
        stage = new Stage(new ScreenViewport());
        Skin mySkin=new Skin(Gdx.files.internal("skin/star-soldier-ui.json"));

        TextButton tank2 = new TextButton("Select",mySkin);
        tank2.setSize(Gdx.graphics.getWidth()/4+10,Gdx.graphics.getHeight()/6-10);
        tank2.setPosition(Gdx.graphics.getWidth()/2-tank2.getWidth()/2+4,Gdx.graphics.getHeight()/2-tank2.getHeight()/2-149);
        tank2.addListener(new InputListener(){
            @Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
                game.setScreen(new GameScreen(game, GameScreen.tank2));
            }
            @Override
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
                return true;
            }
        });
//
        TextButton tank1 = new TextButton("Select",mySkin);
        tank1.setSize(Gdx.graphics.getWidth()/4+10,Gdx.graphics.getHeight()/6-10);
        tank1.setPosition(Gdx.graphics.getWidth()/2-tank1.getWidth()/2-201, Gdx.graphics.getHeight()/2-tank1.getHeight()/2-149);
        tank1.addListener(new InputListener(){
            @Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
                game.setScreen(new GameScreen(game,GameScreen.tank1));
            }
            @Override
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
                return true;
            }
        });



        TextButton tank3 = new TextButton("Select",mySkin);
        tank3.setSize(Gdx.graphics.getWidth()/4+10,Gdx.graphics.getHeight()/6-10);
        tank3.setPosition(tank2.getX()+205, tank2.getY());
        tank3.addListener(new InputListener(){
            @Override
            public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
                game.setScreen(new GameScreen(game,GameScreen.tank3));
            }
            @Override
            public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
                return true;
            }
        });


        batch = new SpriteBatch();
        img = new Texture("Saved Games.png");
        if(GameScreen.flag==1){
        stage.addActor(tank1);}
        if(GameScreen.flag==2){
            stage.addActor(tank1);
            stage.addActor(tank2);}
        if(GameScreen.flag==3){
            stage.addActor(tank1);
            stage.addActor(tank2);
            stage.addActor(tank3);}


    }

    public void create () {

    }


    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        batch.begin();
        batch.draw(img, 0, 20,638,440);
        batch.end();
        stage.act();
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose () {
        batch.dispose();
        img.dispose();
        stage.dispose();
    }
}

