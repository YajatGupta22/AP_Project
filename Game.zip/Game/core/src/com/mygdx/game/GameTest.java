package com.mygdx.game;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class GameTest {
    @Test(expected = NullPointerException.class)
    public void Health() {
        TankMovement Tank = new TankMovement();

    }

    @Test
    public void Position() {
        Projectile bullet = new Projectile(100, 100);
        bullet.Update(1);
        assertEquals(200, (int) bullet.getX());
    }
}